---
name: OmniCX resume state
description: Non-obvious runtime decision from restoring the OmniCX implementation snapshot.
---

The current OmniCX demo runs its customer-experience routes through the deterministic in-memory API layer. The optional Clerk publishing middleware is intentionally not active in this resumed state.

**Why:** The uploaded implementation included auth middleware imports without the corresponding installed packages, which prevented the API workflow from starting; the active demo routes do not require auth to render or operate.

**How to apply:** If authentication or published Clerk proxy behavior is added later, install and configure the Clerk dependencies as a deliberate follow-up before re-enabling that middleware.