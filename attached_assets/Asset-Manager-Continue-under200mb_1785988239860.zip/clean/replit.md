# OmniCX AI

OmniCX AI is a customer-experience command center with a customer self-service portal, AI-assisted support workflows, customer 360 context, and CX intelligence views.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/omnicx-ai/src/App.tsx` — customer and operator routes, interaction state, and shared app shell
- `artifacts/omnicx-ai/src/index.css` — OmniCX visual tokens and responsive theme
- `artifacts/api-server/src/routes/cx.ts` — CX dashboard, tickets, customers, insights, chat, and copilot endpoints
- `lib/api-spec/openapi.yaml` — source-of-truth API contract
- `lib/api-client-react/src/generated/` — generated React Query client hooks
- `lib/api-zod/src/generated/` — generated request/response validators

## Architecture decisions

- The app uses the shared API server and OpenAPI-generated React Query hooks so frontend actions and backend responses share one typed contract.
- The first release uses a deterministic in-memory CX data layer to make the complete interaction surface runnable immediately; persistence can be added without changing the frontend contract.
- CX routes validate request bodies and path parameters with generated Zod schemas before mutating or returning data.
- All AI-facing UI flows go through backend proxy endpoints (`/api/cx/chat` and `/api/cx/copilot`), keeping any future model credentials server-side.

## Product

OmniCX AI includes a public landing page, customer portal, AI support chat, feedback capture, executive command center, unified ticket queue, ticket detail workspace with copilot, customer 360 directory, and CX intelligence insights.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After changing `lib/api-spec/openapi.yaml`, run `pnpm --filter @workspace/api-spec run codegen`.
- This workspace's generated validators are backed by the Zod 3 runtime, so OpenAPI integer fields are represented as numeric fields in the contract to avoid unsupported `z.int()` output.
- Restart `artifacts/api-server: API Server` and `artifacts/omnicx-ai: web` after route, contract, or frontend changes.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
